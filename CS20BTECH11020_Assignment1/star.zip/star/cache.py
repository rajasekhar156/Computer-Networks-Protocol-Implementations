import socket

serverIP = "10.0.1.3"

dst_ip = str(input("Enter dstIP: "))
s = socket.socket()

print(dst_ip)

port = 12345

s.connect((dst_ip, port))

#Write your code here:
#1. Add code to send HTTP GET / PUT / DELETE request. The request should also include KEY.
#2. Add the code to parse the response you get from the server.


dictionary = {}
dst_ip = str(input("Enter Cache IP: "))

s1 = socket.socket()
print ("Socket successfully created")

dport = 12346

s1.bind((dst_ip, dport))
print ("socket binded to %s" %(dport))

s1.listen(5)
print ("socket is listening")

c, addr = s1.accept()
print ('Got connection from', addr )
recvmsg = c.recv(1024).decode()
out_msg = ""
temp = 1

while recvmsg:
	print('Server received '+recvmsg)
	words = recvmsg.split('/')
	if(len(words)==3 and words[0] == "GET " and words[2] == "1.1\r\n\r\n"):
		temp = words[1].split('=')
		if(len(temp)==2 and temp[0] == "assignment1?request"):
			temp1 = temp[1].split(' ')
			if(len(temp1)==2 and temp1[1] == "HTTP"):
				r = dictionary.get(temp1[0],"NoT_fOuNd")
				if(r == "NoT_fOuNd"):
					s.send(recvmsg.encode())
					out_msg = s.recv(1024).decode()
					if(out_msg == "HTTP/1.1 200 OK\r\n\r\n"):
						out_msg2 = s.recv(1024).decode()
						temp = 10
						#######################################################storing in cache of requested element details
						dictionary[temp1[0]]=out_msg2
				else:
					out_msg = "HTTP/1.1 200 OK\r\n\r\n"
					out_msg2 = dictionary[temp1[0]] + "\r\n\r\n"
					temp = 10
			else:
				out_msg = "400 BAD Request"
		else:
			out_msg = "400 BAD Request"
	elif(len(words)==5 and words[0 ] == "PUT " and words[1] == "assignment1" and words[4] == "1.1\r\n\r\n"):
		temp = words[3].split(' ')
		if(len(temp)==2 and temp[1] == "HTTP"):
			dictionary[words[2]]=temp[0]
			s.send(recvmsg.encode())
			out_msg = s.recv(1024).decode()
		else:
			out_msg = "400 BAD Request"
	elif(len(words)==4 and words[0] == "DELETE " and words[1] == "assignment1" and words[3] == "1.1\r\n\r\n"):
		temp = words[2].split(' ')
		if(len(temp)==2 and temp[1] == "HTTP"):
			r = dictionary.get(temp[0],"NoT_fOuNd")
			if(r == "NoT_fOuNd"):
				s.send(recvmsg.encode())
				out_msg = s.recv(1024).decode()
			else:
				del dictionary[temp[0]]
				s.send(recvmsg.encode())
				out_msg = s.recv(1024).decode()
		else:
			out_msg = "400 BAD Request"
	else:
		out_msg = "400 BAD Request"

 	c.send(out_msg.encode())
	if(temp==10):
		c.send(out_msg2.encode())
		temp=1
 	recvmsg = c.recv(1024).decode()

s.close()

  #Write your code here
  #1. Uncomment c.send
  #2. Parse the received HTTP request
  #3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
  #4. Send response
  ##################
#c.close()
  #break
