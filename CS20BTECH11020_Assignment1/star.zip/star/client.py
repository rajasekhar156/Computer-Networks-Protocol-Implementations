import socket

serverIP = "10.0.1.2"

dst_ip = str(input("Enter dstIP: "))
s = socket.socket()

print(dst_ip)

port = 12346

s.connect((dst_ip, port))

#Write your code here:
#1. Add code to send HTTP GET / PUT / DELETE request. The request should also include KEY.
#2. Add the code to parse the response you get from the server.
# mess = [	"GET /assignment1?request=key1 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key1 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key1 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key2 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key2 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key2 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key3 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key3 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key3 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key4 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key4 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key4 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key5 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key5 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key5 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key6 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key6 HTTP/1.1\r\n\r\n",
# 			"GET /assignment1?request=key6 HTTP/1.1\r\n\r\n"	]
#
#
# i=0
# while(i<18):
# 	#mess = str(input("Enter the request: "))
# 	s.send(mess[i].encode())
# 	temp = s.recv(1024).decode()
# 	print ('Client received '+ temp )
# 	if(temp == "HTTP/1.1 200 OK\r\n\r\n" and mess[0][0] == 'G'):
# 		print(s.recv(1024).decode())
# 	i=i+1



while(1):
	mess = str(input("Enter the request: "))
	s.send(mess.encode())
	temp = s.recv(1024).decode()
	print ('Client received '+ temp )
	if(temp == "HTTP/1.1 200 OK\r\n\r\n" and mess[0][0] == 'G'):
		print(s.recv(1024).decode())

s.close()
