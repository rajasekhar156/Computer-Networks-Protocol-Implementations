import socket
#1. Create a KEY-VALUE pairs (Create a dictionary OR Maintain a text file for KEY-VALUES).
Dictionary = {"key1" : "val1" , "key2" : "val2" , "key3" : "val3" , "key4" : "val4" , "key5" : "val5" , "key6" : "val6" , "key7" : "val7" }

dst_ip = str(input("Enter Server IP: "))

s = socket.socket()
print ("Socket successfully created")

dport = 12345

s.bind((dst_ip, dport))
print ("socket binded to %s" %(dport))

s.listen(5)
print ("socket is listening")

c, addr = s.accept()
print ('Got connection from', addr )
recvmsg = c.recv(1024).decode()

out_msg = ""
temp = 1

while recvmsg:
	print('Server received '+recvmsg)
	words = recvmsg.split('/')
	if(len(words)==3 and words[0] == "GET " and words[2] == "1.1\r\n\r\n"):
		temp = words[1].split('=')
		if(len(temp)==2 and temp[0] == "assignment1?request"):
			temp1 = temp[1].split(' ')
			if(len(temp)==2 and temp1[1] == "HTTP"):
				r = Dictionary.get(temp1[0],"NoT_fOuNd")
				if(r == "NoT_fOuNd"):
					out_msg = "404 NOT Found\r\n\r\n"
				else:
					out_msg = "HTTP/1.1 200 OK\r\n\r\n"
					out_msg2 = Dictionary[temp1[0]] + "\r\n\r\n"
					temp = 10
			else:
				out_msg = "400 BAD Request"
		else:
			out_msg = "400 BAD Request"
	elif(len(words)==5 and words[0 ] == "PUT " and words[1] == "assignment1" and words[4] == "1.1\r\n\r\n"):
		temp = words[3].split(' ')
		if(len(temp)==2 and temp[1] == "HTTP"):
			Dictionary[words[2]]=temp[0]
			out_msg = "HTTP/1.1 200 OK\r\n\r\n"
		else:
			out_msg = "400 BAD Request"
	elif(len(words)==4 and words[0] == "DELETE " and words[1] == "assignment1" and words[3] == "1.1\r\n\r\n"):
		temp = words[2].split(' ')
		if(len(temp)==2 and temp[1] == "HTTP"):
			r = Dictionary.get(temp[0],"NoT_fOuNd")
			if(r == "NoT_fOuNd"):
				out_msg = "404 NOT Found\r\n\r\n"
			else:
				del Dictionary[temp[0]]
				out_msg= "HTTP/1.1 200 OK\r\n\r\n"
		else:
			out_msg = "400 BAD Request"
	else:
		out_msg = "400 BAD Request"

 	c.send(out_msg.encode())
	if(temp==10):
		c.send(out_msg2.encode())
		temp=1

 	recvmsg = c.recv(1024).decode()




  #Write your code here
  #1. Uncomment c.send
  #2. Parse the received HTTP request
  #3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
  #4. Send response
  ##################
#c.close()
  #break
